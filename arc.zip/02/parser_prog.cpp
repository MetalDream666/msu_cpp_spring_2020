#include "parser.h"

void fStart()
{
	cout << "Start parsing" << endl;
}

void fEnd()
{
	cout << "End parsing" << endl;
}

void fString(const string& s)
{
	cout << "This is string '" << s.c_str() << "'" << endl;
}

void fNumber(int x)
{
	cout << "This is number " << x << endl;
}

int main()
{
	Parser p;
	
	p.registerCallbackFunctionOnStart(fStart);
	p.registerCallbackFunctionOnEnd(fEnd);
	p.registerCallbackFunctionOnString(fString);
	p.registerCallbackFunctionOnNumber(fNumber);
		
	string a = string("    eto   stroka 12345 haha lol	");
	int err = p.handle(a);
	return err;
}
