#include "parser.h"

int Parser::handle(string ss)
{
	
	parse(ss);
	if(fStartParser == nullptr)
	{
		cout << "StartParser function not defined" << endl;
		return 1;
	}
	if(fStartParser == nullptr)
	{
		cout << "EndParser function not defined" << endl;
		return 2;
	}
	if(fStartParser == nullptr)
	{
		cout << "StringHandle function not defined" << endl;
		return 3;
	}
	if(fStartParser == nullptr)
	{
		cout << "NumberHandle function not defined" << endl;
		return 4;
	}
	
	fStartParser();
	
	for(int i = 0; i < vsize; i++)
	{
		if(isNum(sts[i]))
		{
			fNumberHandle(stoi(sts[i]));
		}
		else
		{
			fStringHandle(sts[i]);
		}
	}
	fEndParser();
	return 0;
}

bool Parser::isNum(string s)
{
	return (isdigit(s[0]));
}

void Parser::registerCallbackFunctionOnStart(fStartEndType onStart)
{
	fStartParser = onStart;
}

void Parser::registerCallbackFunctionOnEnd(fStartEndType onEnd)
{
	fEndParser = onEnd;
}

void Parser::registerCallbackFunctionOnString(fStringType onString)
{
	fStringHandle = onString;
}

void Parser::registerCallbackFunctionOnNumber(fNumberType onNumber)
{
	fNumberHandle = onNumber;
}
